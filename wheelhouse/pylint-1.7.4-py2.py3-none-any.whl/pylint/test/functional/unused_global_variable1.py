# pylint: disable=missing-docstring
VAR = 'pylint'
