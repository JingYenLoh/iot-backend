""" Code for checking the display of the module
for unbalanced-tuple-unpacking and unpacking-non-sequence
"""

def unpack():
    """ Return something"""
    return (1, 2, 3)

def nonseq():
    """ Return non sequence """
    return 1
