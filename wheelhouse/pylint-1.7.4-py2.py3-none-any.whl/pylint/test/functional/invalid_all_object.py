# pylint: disable=missing-docstring
__all__ = (
    1, # [invalid-all-object]
    lambda: None, # [invalid-all-object]
    None, # [invalid-all-object]
)
