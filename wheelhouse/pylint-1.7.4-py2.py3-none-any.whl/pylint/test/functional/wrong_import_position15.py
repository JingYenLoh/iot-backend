"""Checks import position rule with pep-0008"""
# pylint: disable=unused-import

__author__ = 'some author'
__email__ = 'some.author@some_email'
__copyright__ = 'Some copyright'


import sys
