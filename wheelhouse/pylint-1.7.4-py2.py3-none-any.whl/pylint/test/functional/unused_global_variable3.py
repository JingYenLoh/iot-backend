# pylint: disable=missing-docstring
VAR = 'pylint'


def func(argument):
    return VAR + argument
