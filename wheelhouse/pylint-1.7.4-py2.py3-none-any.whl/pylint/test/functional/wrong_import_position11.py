"""Checks import position rule"""
# pylint: disable=unused-import,pointless-string-statement
A = 1
import os  # [wrong-import-position]
